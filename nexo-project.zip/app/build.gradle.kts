plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Fixed signing key GitHub secrets se aati hai (workflow isse env me deta hai).
// Na mile to debug key se sign hota hai, build tab bhi chalti hai.
val keystorePath: String? = System.getenv("KEYSTORE_FILE")
val keystorePass: String? = System.getenv("KEYSTORE_PASSWORD")
val hasFixedKey = keystorePath != null && keystorePass != null && file(keystorePath).exists()

android {
    namespace = "com.padhai.mode"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.padhai.mode"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    signingConfigs {
        if (hasFixedKey) {
            create("padhai") {
                storeFile = file(keystorePath!!)
                storePassword = keystorePass
                keyAlias = "padhai"
                keyPassword = keystorePass
            }
        }
    }

    buildTypes {
        debug {
            // Debuggable APK me adb run-as se app ka data badla ja sakta hai, isliye band.
            isDebuggable = false
            if (hasFixedKey) signingConfig = signingConfigs.getByName("padhai")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
}
