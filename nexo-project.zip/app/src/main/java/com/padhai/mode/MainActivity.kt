package com.padhai.mode

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = NexoColors, shapes = NexoShapes) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

private val Accent = Color(0xFFB7A6FF)
private val Ink = Color(0xFFF2F1F7)
private val Muted = Color(0xFF8E8C9C)
private val Panel = Color(0xFF0F0F13)
private val PanelHigh = Color(0xFF18181F)
private val Line = Color(0xFF26262F)

private val NexoColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF14102B),
    primaryContainer = Color(0xFF2A2350),
    onPrimaryContainer = Ink,
    secondaryContainer = PanelHigh,
    onSecondaryContainer = Ink,
    background = Color.Black,
    onBackground = Ink,
    surface = Color.Black,
    onSurface = Ink,
    surfaceVariant = PanelHigh,
    onSurfaceVariant = Muted,
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Panel,
    surfaceContainer = Panel,
    surfaceContainerHigh = PanelHigh,
    surfaceContainerHighest = PanelHigh,
    errorContainer = Color(0xFF241014),
    onErrorContainer = Color(0xFFFFD9DE),
    outline = Color(0xFF3A3A46),
    outlineVariant = Line
)

private val NexoShapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

/** Black screen par halka panel + patli border wala card. */
@Composable
fun NexoCard(
    modifier: Modifier = Modifier,
    color: Color = Panel,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink),
        border = BorderStroke(1.dp, Line),
        content = content
    )
}

data class AppItem(val pkg: String, val label: String)

fun isServiceEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val cn = ComponentName(ctx, BlockerService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

suspend fun loadApps(ctx: Context): List<AppItem> = withContext(Dispatchers.IO) {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun startOfDay(): Long {
    val c = java.util.Calendar.getInstance()
    c.set(java.util.Calendar.HOUR_OF_DAY, 0)
    c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0)
    c.set(java.util.Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun startOfMonth(): Long {
    val c = java.util.Calendar.getInstance()
    c.set(java.util.Calendar.DAY_OF_MONTH, 1)
    c.set(java.util.Calendar.HOUR_OF_DAY, 0)
    c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0)
    c.set(java.util.Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun fmtStudy(ms: Long): String {
    val totalMin = ms / 60_000L
    val h = totalMin / 60
    val m = totalMin % 60
    return when {
        h == 0L -> "$m min"
        h == 1L -> "1 hr $m min"
        else -> "$h hrs $m min"
    }
}

fun fmt(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

fun isIgnoringBattery(ctx: Context): Boolean {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

fun tryStart(ctx: Context, intent: Intent): Boolean =
    try {
        ctx.startActivity(intent)
        true
    } catch (_: Exception) {
        false
    }

fun openAppInfo(ctx: Context) {
    tryStart(
        ctx,
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

fun openBatterySettings(ctx: Context) {
    val direct = Intent(
        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
        Uri.parse("package:${ctx.packageName}")
    )
    if (tryStart(ctx, direct)) return
    if (tryStart(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) return
    openAppInfo(ctx)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var allowed by remember { mutableStateOf(Prefs.getAllowed(ctx)) }

    LaunchedEffect(Unit) {
        if (Prefs.isActive(ctx)) KeepAliveService.start(ctx)
    }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val serviceOn = remember(now) { isServiceEnabled(ctx) }
    val batteryOk = remember(now) { isIgnoringBattery(ctx) }

    if (screen == "pick") {
        PickScreen(initial = allowed) { chosen ->
            allowed = chosen
            Prefs.setAllowed(ctx, chosen)
            screen = "home"
        }
    } else {
        HomeScreen(
            now = now,
            serviceOn = serviceOn,
            batteryOk = batteryOk,
            allowedCount = allowed.size,
            onPick = { screen = "pick" },
            refresh = { now = System.currentTimeMillis() }
        )
    }
}

@Composable
fun HomeScreen(
    now: Long,
    serviceOn: Boolean,
    batteryOk: Boolean,
    allowedCount: Int,
    onPick: () -> Unit,
    refresh: () -> Unit
) {
    val ctx = LocalContext.current
    val end = Prefs.getEnd(ctx)
    val active = now < end
    var minutes by rememberSaveable { mutableStateOf(60f) }
    var strict by rememberSaveable { mutableStateOf(true) }
    var confirmStop by remember { mutableStateOf(false) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Nexo", fontSize = 40.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp)
        Text(
            "While you study, only the apps you choose will open.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        StatsCard(
            todayMs = Prefs.studiedMs(ctx, startOfDay(), now),
            monthMs = Prefs.studiedMs(ctx, startOfMonth(), now)
        )

        if (!serviceOn) SetupCard()
        if (!active) BackgroundCard(batteryOk)

        if (active) {
            NexoCard(Modifier.fillMaxWidth()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 36.dp, horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Study session running", fontWeight = FontWeight.Medium)
                    Text(fmt(end - now), fontSize = 64.sp, fontWeight = FontWeight.Thin, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "Allowed apps: $allowedCount",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (Prefs.isStrict(ctx)) {
                        Text(
                            "Strict mode is on. You can't stop until the time is up.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        OutlinedButton(onClick = { confirmStop = true }) { Text("Stop session") }
                    }
                }
            }
        } else {
            Text("Study time: ${minutes.toInt()} minutes", fontWeight = FontWeight.Medium)
            Slider(
                value = minutes,
                onValueChange = { minutes = it },
                valueRange = 10f..180f,
                steps = 33
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 45, 60, 90).forEach { m ->
                    OutlinedButton(
                        onClick = { minutes = m.toFloat() },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(0.dp)
                    ) { Text("$m min") }
                }
            }

            NexoCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Allowed apps", fontWeight = FontWeight.Medium)
                        Text(
                            if (allowedCount == 0) "No apps chosen yet" else "Apps chosen: $allowedCount",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(onClick = onPick) { Text("Choose") }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Strict mode", fontWeight = FontWeight.Medium)
                    Text(
                        "When on, you can't stop a session early, and Settings and uninstall stay blocked until it ends.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = strict, onCheckedChange = { strict = it })
            }

            if (allowedCount == 0) {
                Text(
                    "No apps allowed, so only the phone dialer will stay open.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    Prefs.startSession(ctx, minutes.toInt(), strict)
                    KeepAliveService.start(ctx)
                    refresh()
                },
                enabled = serviceOn,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) { Text("Start studying") }

            if (!serviceOn) {
                Text(
                    "Finish the setup above before you start.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            title = { Text("Stop the session?") },
            text = { Text("${fmt(end - now)} left. If you stop, all apps will open again.") },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.stopSession(ctx)
                    KeepAliveService.stop(ctx)
                    confirmStop = false
                    refresh()
                }) { Text("Yes, stop") }
            },
            dismissButton = {
                TextButton(onClick = { confirmStop = false }) { Text("No, keep studying") }
            }
        )
    }
}

@Composable
fun StatsCard(todayMs: Long, monthMs: Long) {
    NexoCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            StatItem("Studied today", fmtStudy(todayMs))
            StatItem("This month", fmtStudy(monthMs))
        }
    }
}

@Composable
fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun SetupCard() {
    val ctx = LocalContext.current
    NexoCard(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.errorContainer) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("One setup first", fontWeight = FontWeight.Bold)
            Text(
                "Find 'Nexo' in Accessibility settings and turn it on. " +
                    "It only checks which app is open and reads nothing else."
            )
            Text(
                "If it won't turn on or you see 'Restricted setting': open App info, tap the three dots at the top, " +
                    "choose 'Allow restricted settings', then try again."
            )
            Button(onClick = {
                tryStart(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }) { Text("Open Accessibility settings") }
            OutlinedButton(onClick = { openAppInfo(ctx) }) { Text("Open App info") }
        }
    }
}

@Composable
fun BackgroundCard(batteryOk: Boolean) {
    val ctx = LocalContext.current
    NexoCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Let it run in the background (required)", fontWeight = FontWeight.Bold)
            Text(
                "Phones like Realme, Oppo and Xiaomi kill apps once you close them, " +
                    "and accessibility turns itself off. To prevent this:"
            )
            Text("1. Remove battery restriction", fontWeight = FontWeight.Medium)
            if (batteryOk) {
                Text(
                    "Done, battery is unrestricted.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Button(onClick = { openBatterySettings(ctx) }) { Text("Open battery setting") }
            }
            Text("2. Turn on all three in App info", fontWeight = FontWeight.Medium)
            Text(
                "Open Battery usage, then turn on Allow foreground activity, Allow background activity " +
                    "and Allow auto-launch.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = { openAppInfo(ctx) }) { Text("Open App info") }
            Text("3. Lock it in Recents", fontWeight = FontWeight.Medium)
            Text(
                "Open recent apps, tap the three dots (or lock icon) above the Nexo card and choose Lock. " +
                    "Don't swipe the app away; leave with the Home button.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("4. Keep power saving off", fontWeight = FontWeight.Medium)
            Text(
                "If Power saving or Super power saving is on in Settings > Battery, the phone closes background apps.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, pkg) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = Modifier.size(size))
    } else {
        Spacer(Modifier.size(size))
    }
}

@Composable
fun PickScreen(initial: Set<String>, onDone: (Set<String>) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var selected by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = loadApps(ctx) }
    BackHandler { onDone(selected) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            "Choose allowed apps",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            "These apps stay open while you study. Everything else is blocked.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search apps") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        val list = apps
        if (list == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val shown = list.filter { it.label.contains(query, ignoreCase = true) }
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.pkg }) { app ->
                    val on = app.pkg in selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                selected = if (on) selected - app.pkg else selected + app.pkg
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(app.pkg)
                        Spacer(Modifier.width(12.dp))
                        Text(app.label, Modifier.weight(1f))
                        Checkbox(checked = on, onCheckedChange = null)
                    }
                }
            }
        }

        Button(
            onClick = { onDone(selected) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) { Text("Done (${selected.size} selected)") }
    }
}
