package com.padhai.mode

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

/**
 * Session chalu hone par har naye khule app ko check karta hai.
 * Agar app allowed list mein nahi hai, to seedha Home screen par bhej deta hai.
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastToastAt = 0L
    private var alwaysAllowed: Set<String> = emptySet()

    /** Strict session me ye apps hamesha band: inse accessibility OFF, force stop ya uninstall ho sakta hai. */
    private val escapeApps = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.oplus.appdetail",
        "com.coloros.safecenter",
        "com.oplus.battery",
        "com.coloros.phonemanager",
        "com.oplus.phonemanager"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        rebuildAlwaysAllowed()
        if (Prefs.isActive(this)) KeepAliveService.start(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Prefs.isActive(this)) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (Prefs.isStrict(this) && pkg in escapeApps) {
            blockNow()
            return
        }
        if (pkg in alwaysAllowed) return
        if (pkg in Prefs.getAllowed(this)) return

        // Keyboard ya launcher badla ho sakta hai, list dobara bana ke ek baar aur check karo.
        rebuildAlwaysAllowed()
        if (pkg in alwaysAllowed) return

        blockNow()
    }

    private fun blockNow() {
        performGlobalAction(GLOBAL_ACTION_HOME)

        val now = System.currentTimeMillis()
        if (now - lastToastAt > 2000) {
            lastToastAt = now
            val mins = Prefs.remainingMs(this) / 60_000L + 1
            handler.post {
                Toast.makeText(
                    this,
                    "Padhaai ka time hai! Abhi $mins min baaki hain.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    /** Wo apps jinhe hamesha chalne dena hai: system UI, launcher, keyboard, dialer. */
    private fun rebuildAlwaysAllowed() {
        val set = HashSet<String>()
        set += packageName
        set += listOf(
            "android",
            "com.android.systemui",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller"
        )
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            packageManager.queryIntentActivities(home, 0).forEach { set += it.activityInfo.packageName }
        } catch (_: Exception) {
        }
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { set += it.packageName }
        } catch (_: Exception) {
        }
        try {
            val telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
            telecom.defaultDialerPackage?.let { set += it }
        } catch (_: Exception) {
        }
        alwaysAllowed = set
    }

    override fun onInterrupt() {}
}
