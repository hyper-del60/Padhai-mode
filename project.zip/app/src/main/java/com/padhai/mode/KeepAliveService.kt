package com.padhai.mode

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Session chalte waqt ek chhota foreground service chalata hai (notification ke saath).
 * Isse phone ka battery manager app ko aasani se kill nahi karta, aur accessibility
 * service zinda rehti hai. Session khatam hote hi ye khud band ho jata hai.
 */
class KeepAliveService : Service() {

    private val handler = Handler(Looper.getMainLooper())

    private val checker = object : Runnable {
        override fun run() {
            if (!Prefs.isActive(this@KeepAliveService)) {
                this@KeepAliveService.stopForeground(Service.STOP_FOREGROUND_REMOVE)
                this@KeepAliveService.stopSelf()
            } else {
                handler.postDelayed(this, 5000L)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService ke turant baad startForeground zaroori hai, warna app crash hota hai.
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        handler.removeCallbacks(checker)
        if (Prefs.isActive(this)) {
            handler.postDelayed(checker, 5000L)
            return START_STICKY
        }
        stopForeground(Service.STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(checker)
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Padhai session", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Padhai Mode chal raha hai")
            .setContentText("Is notification ko band mat karo, warna blocking ruk sakti hai.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "padhai_session"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, KeepAliveService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
