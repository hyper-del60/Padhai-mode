package com.padhai.mode

import android.content.Context

/** Allowed apps aur session ka time phone mein save karta hai. */
object Prefs {
    private const val FILE = "padhai_prefs"
    private const val KEY_ALLOWED = "allowed"
    private const val KEY_END = "end_time"
    private const val KEY_STRICT = "strict"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getAllowed(c: Context): Set<String> =
        sp(c).getStringSet(KEY_ALLOWED, emptySet())?.toSet() ?: emptySet()

    fun setAllowed(c: Context, apps: Set<String>) {
        sp(c).edit().putStringSet(KEY_ALLOWED, HashSet(apps)).apply()
    }

    fun getEnd(c: Context): Long = sp(c).getLong(KEY_END, 0L)

    fun isStrict(c: Context): Boolean = sp(c).getBoolean(KEY_STRICT, false)

    fun startSession(c: Context, minutes: Int, strict: Boolean) {
        sp(c).edit()
            .putLong(KEY_END, System.currentTimeMillis() + minutes * 60_000L)
            .putBoolean(KEY_STRICT, strict)
            .apply()
    }

    fun stopSession(c: Context) {
        sp(c).edit().putLong(KEY_END, 0L).apply()
    }

    fun isActive(c: Context): Boolean = System.currentTimeMillis() < getEnd(c)

    fun remainingMs(c: Context): Long = (getEnd(c) - System.currentTimeMillis()).coerceAtLeast(0L)
}
