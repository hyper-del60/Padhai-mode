package com.padhai.mode

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Session chalte waqt ek chhota foreground service chalata hai (notification ke saath).
 * Isse phone ka battery manager app ko aasani se kill nahi karta, aur accessibility
 * service zinda rehti hai. Session khatam hote hi ye khud band ho jata hai.
 */
class KeepAliveService : Service() {

    private val handler = Handler(Looper.getMainLooper())

    private val checker = object : Runnable {
        override fun run() {
            if (!Prefs.isActive(this@KeepAliveService)) {
                cancelAlert()
                this@KeepAliveService.stopForeground(Service.STOP_FOREGROUND_REMOVE)
                this@KeepAliveService.stopSelf()
            } else {
                checkAccessibility()
                handler.postDelayed(this, 5000L)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService ke turant baad startForeground zaroori hai, warna app crash hota hai.
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        handler.removeCallbacks(checker)
        if (Prefs.isActive(this)) {
            handler.postDelayed(checker, 5000L)
            return START_STICKY
        }
        stopForeground(Service.STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(checker)
        super.onDestroy()
    }

    /** Session ke beech accessibility OFF mile to turant alert dikhao, taaki blocking band na rahe. */
    private fun checkAccessibility() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (isServiceEnabled(this)) {
                nm.cancel(ALERT_ID)
                return
            }
            nm.createNotificationChannel(
                NotificationChannel(ALERT_CHANNEL, "Nexo alert", NotificationManager.IMPORTANCE_HIGH)
            )
            val open = PendingIntent.getActivity(
                this,
                1,
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            nm.notify(
                ALERT_ID,
                Notification.Builder(this, ALERT_CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle("Nexo ki accessibility band ho gayi")
                    .setContentText("Tap karke dobara ON karo, warna apps block nahi honge.")
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    private fun cancelAlert() {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ALERT_ID)
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Nexo session", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Nexo chal raha hai")
            .setContentText("Session chal raha hai. Time poora hote hi ye khud hat jayega.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "padhai_session"
        private const val NOTIF_ID = 1
        private const val ALERT_CHANNEL = "padhai_alert"
        private const val ALERT_ID = 2

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, KeepAliveService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
