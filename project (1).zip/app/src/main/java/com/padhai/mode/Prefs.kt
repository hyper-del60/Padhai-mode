package com.padhai.mode

import android.content.Context

/** Allowed apps aur session ka time phone mein save karta hai. */
object Prefs {
    private const val FILE = "padhai_prefs"
    private const val KEY_ALLOWED = "allowed"
    private const val KEY_END = "end_time"
    private const val KEY_STRICT = "strict"
    private const val KEY_LOG = "session_log"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getAllowed(c: Context): Set<String> =
        sp(c).getStringSet(KEY_ALLOWED, emptySet())?.toSet() ?: emptySet()

    fun setAllowed(c: Context, apps: Set<String>) {
        sp(c).edit().putStringSet(KEY_ALLOWED, HashSet(apps)).apply()
    }

    fun getEnd(c: Context): Long = sp(c).getLong(KEY_END, 0L)

    fun isStrict(c: Context): Boolean = sp(c).getBoolean(KEY_STRICT, false)

    fun startSession(c: Context, minutes: Int, strict: Boolean) {
        val now = System.currentTimeMillis()
        val end = now + minutes.coerceIn(10, 180) * 60_000L
        val log = readLog(c)
        log.add(longArrayOf(now, end))
        sp(c).edit()
            .putLong(KEY_END, end)
            .putBoolean(KEY_STRICT, strict)
            .putString(KEY_LOG, encodeLog(log))
            .apply()
    }

    fun stopSession(c: Context) {
        val now = System.currentTimeMillis()
        val log = readLog(c)
        if (log.isNotEmpty()) {
            val last = log[log.size - 1]
            // Session beech me roki gayi to padhne ka time wahin tak ginte hain.
            if (last[1] > now) last[1] = maxOf(now, last[0] + 1)
        }
        sp(c).edit()
            .putLong(KEY_END, 0L)
            .putString(KEY_LOG, encodeLog(log))
            .apply()
    }

    /** Session log: har session ka (start, end). Padhne ka time isi se nikalte hain. */
    private fun readLog(c: Context): MutableList<LongArray> {
        val raw = sp(c).getString(KEY_LOG, "") ?: ""
        val out = mutableListOf<LongArray>()
        for (part in raw.split(';')) {
            val ab = part.split(':')
            if (ab.size != 2) continue
            val a = ab[0].toLongOrNull() ?: continue
            val b = ab[1].toLongOrNull() ?: continue
            if (b > a) out.add(longArrayOf(a, b))
        }
        return out
    }

    private fun encodeLog(list: List<LongArray>): String =
        list.takeLast(600).joinToString(";") { "${it[0]}:${it[1]}" }

    /** [from, to] ke beech kitna time padhai me gaya (chalte session ka abhi tak ka hissa bhi gina jata hai). */
    fun studiedMs(c: Context, from: Long, to: Long): Long {
        var total = 0L
        for (s in readLog(c)) {
            val a = maxOf(s[0], from)
            val b = minOf(s[1], to)
            if (b > a) total += b - a
        }
        return total
    }

    fun isActive(c: Context): Boolean = System.currentTimeMillis() < getEnd(c)

    fun remainingMs(c: Context): Long = (getEnd(c) - System.currentTimeMillis()).coerceAtLeast(0L)
}
