package com.padhai.mode

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

data class AppItem(val pkg: String, val label: String)

fun isServiceEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val cn = ComponentName(ctx, BlockerService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

suspend fun loadApps(ctx: Context): List<AppItem> = withContext(Dispatchers.IO) {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun startOfDay(): Long {
    val c = java.util.Calendar.getInstance()
    c.set(java.util.Calendar.HOUR_OF_DAY, 0)
    c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0)
    c.set(java.util.Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun startOfMonth(): Long {
    val c = java.util.Calendar.getInstance()
    c.set(java.util.Calendar.DAY_OF_MONTH, 1)
    c.set(java.util.Calendar.HOUR_OF_DAY, 0)
    c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0)
    c.set(java.util.Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun fmtStudy(ms: Long): String {
    val totalMin = ms / 60_000L
    val h = totalMin / 60
    val m = totalMin % 60
    return when {
        h == 0L -> "$m min"
        h == 1L -> "1 ghanta $m min"
        else -> "$h ghante $m min"
    }
}

fun fmt(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

fun isIgnoringBattery(ctx: Context): Boolean {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

fun tryStart(ctx: Context, intent: Intent): Boolean =
    try {
        ctx.startActivity(intent)
        true
    } catch (_: Exception) {
        false
    }

fun openAppInfo(ctx: Context) {
    tryStart(
        ctx,
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

fun openBatterySettings(ctx: Context) {
    val direct = Intent(
        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
        Uri.parse("package:${ctx.packageName}")
    )
    if (tryStart(ctx, direct)) return
    if (tryStart(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) return
    openAppInfo(ctx)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var allowed by remember { mutableStateOf(Prefs.getAllowed(ctx)) }

    LaunchedEffect(Unit) {
        if (Prefs.isActive(ctx)) KeepAliveService.start(ctx)
    }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val serviceOn = remember(now) { isServiceEnabled(ctx) }
    val batteryOk = remember(now) { isIgnoringBattery(ctx) }

    if (screen == "pick") {
        PickScreen(initial = allowed) { chosen ->
            allowed = chosen
            Prefs.setAllowed(ctx, chosen)
            screen = "home"
        }
    } else {
        HomeScreen(
            now = now,
            serviceOn = serviceOn,
            batteryOk = batteryOk,
            allowedCount = allowed.size,
            onPick = { screen = "pick" },
            refresh = { now = System.currentTimeMillis() }
        )
    }
}

@Composable
fun HomeScreen(
    now: Long,
    serviceOn: Boolean,
    batteryOk: Boolean,
    allowedCount: Int,
    onPick: () -> Unit,
    refresh: () -> Unit
) {
    val ctx = LocalContext.current
    val end = Prefs.getEnd(ctx)
    val active = now < end
    var minutes by rememberSaveable { mutableStateOf(60f) }
    var strict by rememberSaveable { mutableStateOf(true) }
    var confirmStop by remember { mutableStateOf(false) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Nexo", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "Padhaai ke time sirf wahi apps khulenge jo aap chunoge.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        StatsCard(
            todayMs = Prefs.studiedMs(ctx, startOfDay(), now),
            monthMs = Prefs.studiedMs(ctx, startOfMonth(), now)
        )

        if (!serviceOn) SetupCard()
        if (!active) BackgroundCard(batteryOk)

        if (active) {
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Padhaai chal rahi hai", fontWeight = FontWeight.Medium)
                    Text(fmt(end - now), fontSize = 56.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "$allowedCount apps allowed hain",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (Prefs.isStrict(ctx)) {
                        Text(
                            "Strict mode ON hai. Time poora hone tak rok nahi sakte.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        OutlinedButton(onClick = { confirmStop = true }) { Text("Session rokna hai") }
                    }
                }
            }
        } else {
            Text("Kitni der padhna hai: ${minutes.toInt()} minute", fontWeight = FontWeight.Medium)
            Slider(
                value = minutes,
                onValueChange = { minutes = it },
                valueRange = 10f..180f,
                steps = 33
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 45, 60, 90).forEach { m ->
                    OutlinedButton(
                        onClick = { minutes = m.toFloat() },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(0.dp)
                    ) { Text("$m min") }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Allowed apps", fontWeight = FontWeight.Medium)
                        Text(
                            if (allowedCount == 0) "Abhi koi app nahi chuna" else "$allowedCount apps chune hain",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(onClick = onPick) { Text("Chuno") }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Strict mode", fontWeight = FontWeight.Medium)
                    Text(
                        "ON: session beech me rok nahi sakte, aur tab tak Settings aur uninstall bhi band rahenge.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = strict, onCheckedChange = { strict = it })
            }

            if (allowedCount == 0) {
                Text(
                    "Koi app allowed nahi hai, to sirf phone dialer khula rahega.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    Prefs.startSession(ctx, minutes.toInt(), strict)
                    KeepAliveService.start(ctx)
                    refresh()
                },
                enabled = serviceOn,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) { Text("Padhaai shuru karo") }

            if (!serviceOn) {
                Text(
                    "Shuru karne se pehle upar wala setup poora karo.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            title = { Text("Session rok dein?") },
            text = { Text("Abhi ${fmt(end - now)} baaki hai. Rokne ke baad saare apps khul jayenge.") },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.stopSession(ctx)
                    KeepAliveService.stop(ctx)
                    confirmStop = false
                    refresh()
                }) { Text("Haan, roko") }
            },
            dismissButton = {
                TextButton(onClick = { confirmStop = false }) { Text("Nahi, padhta hoon") }
            }
        )
    }
}

@Composable
fun StatsCard(todayMs: Long, monthMs: Long) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            StatItem("Aaj padha", fmtStudy(todayMs))
            StatItem("Is mahine padha", fmtStudy(monthMs))
        }
    }
}

@Composable
fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SetupCard() {
    val ctx = LocalContext.current
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Pehle ek setup karo", fontWeight = FontWeight.Bold)
            Text(
                "Accessibility settings mein 'Nexo' dhundho aur usse ON karo. " +
                    "Ye sirf dekhta hai ki kaun sa app khula hai, aur kuch nahi padhta."
            )
            Text(
                "Agar ON nahi ho raha ya 'Restricted setting' dikhe: App info kholo, upar teen dot dabao, " +
                    "'Allow restricted settings' chuno, phir dobara try karo."
            )
            Button(onClick = {
                tryStart(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }) { Text("Accessibility settings kholo") }
            OutlinedButton(onClick = { openAppInfo(ctx) }) { Text("App info kholo") }
        }
    }
}

@Composable
fun BackgroundCard(batteryOk: Boolean) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Background me chalne do (zaroori)", fontWeight = FontWeight.Bold)
            Text(
                "Realme, Oppo, Xiaomi jaise phones app close karte hi use kill kar dete hain, " +
                    "aur accessibility apne aap OFF ho jaati hai. Isse bachne ke liye ye karo:"
            )
            Text("1. Battery restriction hatao", fontWeight = FontWeight.Medium)
            if (batteryOk) {
                Text(
                    "Ho gaya, battery unrestricted hai.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Button(onClick = { openBatterySettings(ctx) }) { Text("Battery setting kholo") }
            }
            Text("2. App info me teeno ON karo", fontWeight = FontWeight.Medium)
            Text(
                "Battery usage kholo, phir Allow foreground activity, Allow background activity " +
                    "aur Allow auto-launch teeno ON karo.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = { openAppInfo(ctx) }) { Text("App info kholo") }
            Text("3. Recents me lock karo", fontWeight = FontWeight.Medium)
            Text(
                "Recent apps kholo, Nexo card ke upar wale teen dot (ya lock icon) par tap karke Lock karo. " +
                    "App ko swipe karke close mat karo, Home button se bahar niklo.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("4. Power saving mode OFF rakho", fontWeight = FontWeight.Medium)
            Text(
                "Settings > Battery me Power saving ya Super power saving ON ho to phone background apps band kar deta hai.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, pkg) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = Modifier.size(size))
    } else {
        Spacer(Modifier.size(size))
    }
}

@Composable
fun PickScreen(initial: Set<String>, onDone: (Set<String>) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var selected by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = loadApps(ctx) }
    BackHandler { onDone(selected) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            "Allowed apps chuno",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            "Padhaai ke time ye apps khule rahenge, baaki sab band.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("App dhundho") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        val list = apps
        if (list == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val shown = list.filter { it.label.contains(query, ignoreCase = true) }
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.pkg }) { app ->
                    val on = app.pkg in selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                selected = if (on) selected - app.pkg else selected + app.pkg
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(app.pkg)
                        Spacer(Modifier.width(12.dp))
                        Text(app.label, Modifier.weight(1f))
                        Checkbox(checked = on, onCheckedChange = null)
                    }
                }
            }
        }

        Button(
            onClick = { onDone(selected) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) { Text("Ho gaya (${selected.size} chune)") }
    }
}
