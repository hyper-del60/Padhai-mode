package com.padhai.mode

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Phone restart ho (ya battery khatam hokar dobara on ho) aur session abhi chal raha ho,
 * to keep-alive service wapas chalu kar deta hai. Session ka end time phone me save rehta hai,
 * isliye band rehne ka time bhi timer me ginta hai.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && Prefs.isActive(context)) {
            KeepAliveService.start(context)
        }
    }
}
